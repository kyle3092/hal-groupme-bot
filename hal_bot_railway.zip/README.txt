HAL Railway Bot Setup

1. Upload these files to a GitHub repo (or directly to Railway.app when prompted).
2. Create two environment variables in Railway:
   - GROUPME_BOT_ID = <your GroupMe Bot ID>
   - OPENAI_API_KEY = <your OpenAI API Key>
3. Deploy the project.
4. Use the public Railway URL as your GroupMe Bot's callback URL.

You're good to go! HAL now runs 24/7.
